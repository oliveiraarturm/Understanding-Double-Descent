import numpy as np

def treinaELM_function(xin, yin, p, par):
        n = xin.shape[1]
        if (par == 1) :
            xin = np.block([np.ones((xin.shape[0],1)), xin])
            Z = np.reshape( np.random.uniform(-0.5, 0.5, (n+1) * p) , ((n+1),p))
        else :
            Z = np.reshape( np.random.uniform(-0.5, 0.5, (n) * p) , ((n),p))

        
        H = np.tanh(np.dot(xin,Z))
        Haug = np.block([np.ones((H.shape[0],1)), H])
        W = np.dot(np.linalg.pinv(Haug), yin) 
        
        return [W, H, Z]

def YELM_function(xin, Z, W, par) :
    n = xin.shape[1]

    if (par == 1) :
        xin = np.block([np.ones((xin.shape[0],1)), xin])
    

    H = np.tanh(np.dot(xin , Z))
    Haug = np.block([np.ones((H.shape[0],1)), H])
    Yhat = np.sign(np.dot(Haug , W))
    return (Yhat)

def yperceptron(xvec, w):
    xvec = np.block([np.ones(shape=(xvec.shape[0],1)), xvec])
    u = np.dot(xvec,w)
    y = (u[:]>=0)*1
    return y

def trainperceptron(xin, yd, eta, tol, maxepocas, par):
    [N,n]=xin.shape
    wt = np.random.rand(n + 1, 1) - 0.5 
    xin = np.block([np.ones(shape=(N,1))*-1,xin])
    nepocas=0
    epoca = tol+1
    evec = np.full(maxepocas,np.nan)

    while ((nepocas < maxepocas) and (epoca > tol)):
        ei2 = 0    
        xseq = np.random.permutation(np.arange(0, N))
        for i in range(0,N):
            irand = xseq[i]
            yhat = np.where(np.dot(xin[irand], wt) >= 0, 1, 0)
            ei = yd[irand] - yhat
            dw = eta * ei * xin[irand]
            wt = wt + dw.reshape(n+1,1)           
            ei2 = ei2 + ei * ei
        evec[nepocas] = ei2 / N    
        epoca = evec[nepocas]
        nepocas = nepocas + 1
    
    retlist = [wt, evec]
    
    return retlist